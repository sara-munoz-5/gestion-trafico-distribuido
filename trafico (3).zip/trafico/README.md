# Gestión Inteligente de Tráfico Urbano
**Introducción a Sistemas Distribuidos — PUJ 2026-10**

---

## Requisitos

```bash
pip install pyzmq
```

Python 3.8+. Sin dependencias adicionales.

### Entorno recomendado en 1 Windows (desarrollo local)

```powershell
python --version
python -m pip install --upgrade pip
python -m pip install pyzmq
```

### Entorno recomendado en 3 Ubuntu (despliegue)

Ejecutar en cada máquina Ubuntu:

```bash
sudo apt update
sudo apt install -y python3 python3-pip python3-venv
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install pyzmq
```

---

## Estructura del Proyecto

```
trafico/
  config.json            ← Parámetros globales (IPs, puertos, cuadrícula 4×4, reglas)
  shared/
    modelos.py           ← Clases de dominio: EstadoTrafico, EventoTrafico, ComandoSemaforo
  pc1/
    broker.py            ← Broker ZMQ (XSUB/XPUB proxy)
    sensor_espira.py     ← Sensor espira inductiva → EVENTO_CONTEO_VEHICULAR
    sensor_camara.py     ← Sensor cámara          → EVENTO_LONGITUD_COLA
    sensor_gps.py        ← Sensor GPS              → EVENTO_DENSIDAD_DE_TRAFICO
  pc2/
    reglas.py            ← Módulo de reglas: NORMAL / CONGESTION / PRIORIZACION
    analitica.py         ← Servicio de Analítica (procesamiento + health check)
    semaforos.py         ← Servicio Control de Semáforos (16 semáforos 4×4)
    bd_replica.py        ← BD Réplica SQLite + fallback REP
  pc3/
    bd_principal.py      ← BD Principal SQLite
    monitoreo.py         ← Servicio de Monitoreo y Consulta (menú interactivo)
```

---

## Configuración de IPs (antes de ejecutar en 3 máquinas)

Editar `config.json`:
```json
"red": {
  "pc1_ip": "192.168.X.X",   ← IP real de PC1
  "pc2_ip": "192.168.X.X",   ← IP real de PC2
  "pc3_ip": "192.168.X.X"    ← IP real de PC3
}
```

Para ejecutar todo en **una sola máquina** (desarrollo), dejar `127.0.0.1`.

Para ejecutar en **3 máquinas Ubuntu**, usar IPs reales de la red local, por ejemplo:

```json
"red": {
  "pc1_ip": "192.168.1.10",
  "pc2_ip": "192.168.1.20",
  "pc3_ip": "192.168.1.30",
  "broker_pub_port": 5555,
  "broker_sub_port": 5556,
  "bd_replica_port": 5557,
  "semaforos_port": 5558,
  "bd_principal_port": 5559,
  "analitica_rep_port": 5560,
  "monitoreo_rep_port": 5561,
  "bd_replica_rep_port": 5562
}
```

Nota: abrir en firewall los puertos 5555-5562 entre máquinas.

---

## Orden de Ejecución

Abrir una terminal por proceso. El orden recomendado: BDs, semáforos, analítica, broker, sensores, monitoreo.

### Escenario A: 1 máquina Windows (todo local)

Desde la carpeta raíz `trafico\` en PowerShell:

```powershell
# Terminal 1 — BD Principal (PC3)
python pc3\bd_principal.py --config config.json

# Terminal 2 — BD Réplica (PC2)
python pc2\bd_replica.py --config config.json

# Terminal 3 — Control de Semáforos (PC2)
python pc2\semaforos.py --config config.json

# Terminal 4 — Analítica (PC2)
python pc2\analitica.py --config config.json

# Terminal 5 — Broker (PC1)
python pc1\broker.py --config config.json

# Terminales 6,7,8 — Sensores base (uno por tipo)
python pc1\sensor_espira.py --idx 0 --config config.json
python pc1\sensor_camara.py --idx 0 --config config.json
python pc1\sensor_gps.py --idx 0 --config config.json

# Opcional para cubrir las 16 intersecciones (recomendado en demo)
# Lanzar también --idx 1, --idx 2 y --idx 3 de cada tipo.

# Terminal 9 — Monitoreo (PC3)
python pc3\monitoreo.py --config config.json
```

### Escenario B: 3 máquinas Ubuntu (distribuido)

En cada máquina, ubicar el proyecto en una ruta local, por ejemplo `~/trafico`, y activar el entorno virtual.

PC1 (Broker + Sensores):

```bash
cd ~/trafico
source .venv/bin/activate
python3 pc1/broker.py --config config.json
```

En terminales adicionales de PC1:

```bash
cd ~/trafico
source .venv/bin/activate
python3 pc1/sensor_espira.py --idx 0 --config config.json
python3 pc1/sensor_camara.py --idx 0 --config config.json
python3 pc1/sensor_gps.py --idx 0 --config config.json
```

PC2 (BD Réplica + Semáforos + Analítica):

```bash
cd ~/trafico
source .venv/bin/activate
python3 pc2/bd_replica.py --config config.json
python3 pc2/semaforos.py --config config.json
python3 pc2/analitica.py --config config.json
```

PC3 (BD Principal + Monitoreo):

```bash
cd ~/trafico
source .venv/bin/activate
python3 pc3/bd_principal.py --config config.json
python3 pc3/monitoreo.py --config config.json
```

Resumen de despliegue por máquina:

| Máquina | Módulos principales |
|---------|---------------------|
| PC1 | `pc1/`, `shared/`, `config.json` |
| PC2 | `pc2/`, `shared/`, `config.json` |
| PC3 | `pc3/`, `shared/`, `config.json` |

---

## Cuadrícula de la Ciudad (4×4)

```
     Col 1    Col 2    Col 3    Col 4
  ┌────────┬────────┬────────┬────────┐
A │ INT_A1 │ INT_A2 │ INT_A3 │ INT_A4 │
  ├────────┼────────┼────────┼────────┤
B │ INT_B1 │ INT_B2 │ INT_B3 │ INT_B4 │
  ├────────┼────────┼────────┼────────┤
C │ INT_C1 │ INT_C2 │ INT_C3 │ INT_C4 │
  ├────────┼────────┼────────┼────────┤
D │ INT_D1 │ INT_D2 │ INT_D3 │ INT_D4 │
  └────────┴────────┴────────┴────────┘
```

Sensores asignados (por config.json):
- **Espiras**: A1, B3, C2, D4
- **Cámaras**: A3, B2, C4, D1
- **GPS**:     A2, B4, C1, D3

---

## Reglas de Tráfico

| Estado       | Condición                              | Acción semáforo               |
|-------------|----------------------------------------|-------------------------------|
| NORMAL       | Q<5 AND Vp>35 AND V<15               | Ciclo estándar 15s/15s        |
| CONGESTION   | Q≥5 OR Vp≤20 OR V≥20                | Verde extendido a 30s         |
| PRIORIZACION | Comando manual del operador           | Ola verde en la vía indicada  |

---

## Prueba de Tolerancia a Fallos

1. Iniciar el sistema completo
2. Verificar que BD Principal recibe eventos (logs de `bd_principal.py`)
3. Detener `bd_principal.py` (Ctrl+C) para simular caída de PC3
4. Observar en `analitica.py`: `❌ PC3 CAÍDO — usando BD Réplica como primaria`
5. Verificar que `bd_replica.py` sigue recibiendo eventos
6. Reiniciar `bd_principal.py` → `analitica.py` imprime `✅ PC3 recuperado`

---

## Medición de Throughput (para experimentos de la Tabla 1)

```bash
# Contar registros en BD antes del experimento
sqlite3 bd_principal.sqlite "SELECT COUNT(*) FROM eventos;"

# Esperar 120 segundos

# Contar registros al final
sqlite3 bd_principal.sqlite "SELECT COUNT(*) FROM eventos;"

# Throughput = conteo_final - conteo_inicial
```

---

## Escenarios de Carga (Tabla 1 del enunciado)

```bash
# Escenario A: 1 sensor de cada tipo, intervalo 10s
python sensor_espira.py --idx 0 --intervalo 10
python sensor_camara.py --idx 0 --intervalo 10
python sensor_gps.py    --idx 0 --intervalo 10

# Escenario B: 2 sensores de cada tipo, intervalo 5s
python sensor_espira.py --idx 0 --intervalo 5 &
python sensor_espira.py --idx 1 --intervalo 5 &
python sensor_camara.py --idx 0 --intervalo 5 &
python sensor_camara.py --idx 1 --intervalo 5 &
python sensor_gps.py    --idx 0 --intervalo 5 &
python sensor_gps.py    --idx 1 --intervalo 5 &
```
