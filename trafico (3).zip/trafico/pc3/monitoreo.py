"""
monitoreo.py — Servicio de Monitoreo y Consulta (PC3)

Interfaz interactiva de línea de comandos para el operador.
Implementa los 4 tipos de consulta y las 4 indicaciones directas
definidas en el documento del grupo (secciones 8 y 9).

Uso:
    python monitoreo.py
    python monitoreo.py --config ../../config.json
"""
import zmq
import json
import argparse
import sys
import os
import time
from datetime import datetime, timezone

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, ROOT)
from shared.modelos import ts_now

SEP = "─" * 65


class ServicioMonitoreo:
    """Cliente interactivo para consultar estado y enviar comandos al sistema."""

    def __init__(self, cfg: dict):
        """Inicializa endpoints REQ y configuración de timeout de solicitudes."""
        self.cfg = cfg
        self.red = cfg["red"]
        self.timeout_ms = 5000

        self.ctx = zmq.Context()

        self.endpoint_analitica = (
            f"tcp://{self.red['pc2_ip']}:{self.red['analitica_rep_port']}")
        self.endpoint_bd_principal = (
            f"tcp://{self.red['pc3_ip']}:{self.red['monitoreo_rep_port']}")
        self.endpoint_bd_replica = (
            f"tcp://{self.red['pc2_ip']}:{self.red['bd_replica_rep_port']}")

        print(f"[MONITOREO] {ts_now()} — Servicio de Monitoreo iniciado")

    # ── Comunicación ─────────────────────────────────────────────────────────

    def _req_json(self, endpoint: str, cmd: dict) -> dict:
        """Envía un comando JSON y retorna respuesta JSON en una sola solicitud."""
        # Usar socket REQ por solicitud evita estados inválidos tras timeout.
        sock = self.ctx.socket(zmq.REQ)
        sock.setsockopt(zmq.RCVTIMEO, self.timeout_ms)
        sock.setsockopt(zmq.LINGER, 0)
        sock.connect(endpoint)
        try:
            sock.send_string(json.dumps(cmd))
            return json.loads(sock.recv_string())
        finally:
            sock.close()

    def _analitica(self, cmd: dict) -> dict:
        """Enruta comandos operativos al servicio de Analítica."""
        try:
            return self._req_json(self.endpoint_analitica, cmd)
        except zmq.ZMQError as e:
            print(f"  [!] Error al contactar Analítica: {e}")
            return {"status": "ERROR"}

    def _bd(self, cmd: dict) -> dict:
        """Consulta BD principal y hace fallback a réplica ante indisponibilidad."""
        try:
            return self._req_json(self.endpoint_bd_principal, cmd)
        except zmq.ZMQError:
            print("  [!] BD Principal no disponible, intentando réplica...")
            try:
                return self._req_json(self.endpoint_bd_replica, cmd)
            except zmq.ZMQError as e:
                print(f"  [!] Error también en réplica: {e}")
                return {"status": "ERROR"}

    # ════════════════════════════════════════════════════════════════
    # SECCIÓN 8 — TIPOS DE CONSULTA
    # ════════════════════════════════════════════════════════════════

    def consulta_estado_actual(self) -> None:
        """8.1 Estado actual de una intersección (nivel congestión, vel, semáforo)."""
        print("\n🔍 CONSULTA DE ESTADO ACTUAL")
        inter = input("  Intersección (ej. INT_B2): ").strip().upper()
        r = self._bd({"tipo": "INTERSECCION", "interseccion": inter})
        print(f"\n  {SEP}")
        if r.get("status") == "OK" and r.get("dato"):
            d = r["dato"]
            print(f"  Intersección : {d[3]}")
            print(f"  Último estado: {d[4]}")
            print(f"  Timestamp    : {d[5]}")
            print(f"  Fuente       : {r.get('fuente','BD')}")
        else:
            print("  Sin datos para esa intersección.")

    def consulta_historica(self) -> None:
        """8.2 Consulta histórica por intervalo de tiempo."""
        print("\n📅 CONSULTA HISTÓRICA")
        ini = input("  Inicio (YYYY-MM-DDTHH:MM:SSZ) [Enter = hoy 00:00]: ").strip()
        fin = input("  Fin    (YYYY-MM-DDTHH:MM:SSZ) [Enter = ahora]:     ").strip()
        ts_ini = ini or datetime.now(timezone.utc).strftime("%Y-%m-%dT00:00:00+00:00")
        ts_fin = fin or ts_now()
        r = self._bd({"tipo": "HISTORICO", "inicio": ts_ini, "fin": ts_fin})
        print(f"\n  {SEP}")
        if r.get("status") == "OK":
            evs = r.get("eventos", [])
            print(f"  Fuente: {r.get('fuente','BD')} | Total: {r.get('total', len(evs))} eventos")
            for ev in evs[:20]:
                print(f"  [{ev[4]}] {ev[2]} — {ev[3]}")
            if len(evs) > 20:
                print(f"  ... (+{len(evs)-20} más)")
        else:
            print("  Sin resultados o error.")

    def consulta_eventos_recientes(self) -> None:
        """8.3 Eventos recientes de una intersección."""
        print("\n📡 EVENTOS RECIENTES")
        inter = input("  Intersección (ej. INT_A3): ").strip().upper()
        r = self._bd({"tipo": "EVENTOS_RECIENTES", "interseccion": inter})
        print(f"\n  {SEP}")
        if r.get("status") == "OK":
            evs = r.get("eventos", [])
            print(f"  Últimos {len(evs)} eventos en {inter}:")
            for ev in evs:
                print(f"  [{ev[5]}] tópico={ev[2]} estado={ev[4]}")
        else:
            print("  Sin eventos o error.")

    def consulta_estado_semaforos(self) -> None:
        """8.4 Estado actual de todos los semáforos."""
        print("\n🚦 ESTADO DE SEMÁFOROS")
        r = self._bd({"tipo": "ESTADO_SEMAFOROS"})
        print(f"\n  {SEP}")
        if r.get("status") == "OK":
            estados = r.get("estados", [])
            print(f"  {'Intersección':<14} {'Estado':<12} {'Última lectura'}")
            print(f"  {'-'*14} {'-'*12} {'-'*30}")
            for e in estados:
                print(f"  {e['interseccion']:<14} {e['estado']:<12} {e['ts']}")
        else:
            print("  No se pudo obtener el estado de los semáforos.")

    # ════════════════════════════════════════════════════════════════
    # SECCIÓN 9 — INDICACIONES DIRECTAS AL SISTEMA
    # ════════════════════════════════════════════════════════════════

    def forzar_cambio_semaforo(self) -> None:
        """9.1 Forzar cambio de estado en una intersección específica."""
        print("\n🔧 FORZAR CAMBIO DE SEMÁFORO")
        inter  = input("  Intersección (ej. INT_C3): ").strip().upper()
        estado = input("  Estado (VERDE / ROJO):     ").strip().upper()
        if estado not in ("VERDE", "ROJO"):
            print("  Estado inválido.")
            return
        tipo = "FORZAR_VERDE" if estado == "VERDE" else "FORZAR_ROJO"
        t0 = time.time()
        r  = self._analitica({"tipo": tipo, "interseccion": inter})
        lat = int((time.time() - t0) * 1000)
        print(f"  Resultado: {r.get('status')} | Latencia: {lat} ms")

    def priorizar_via(self) -> None:
        """9.2 Activar ola verde en una vía completa (ambulancia u otro)."""
        print("\n🚑 PRIORIZAR VÍA — OLA VERDE")
        fila = input("  Fila a priorizar (A / B / C / D): ").strip().upper()
        if fila not in self.cfg["ciudad"]["filas"]:
            print(f"  Fila inválida. Opciones: {self.cfg['ciudad']['filas']}")
            return
        t0 = time.time()
        r  = self._analitica({"tipo": "PRIORIZAR_VIA", "fila": fila})
        lat = int((time.time() - t0) * 1000)
        print(f"  Resultado : {r.get('status')}")
        print(f"  Afectados : {r.get('afectados', [])}")
        print(f"  Latencia  : {lat} ms")

    def simular_evento_especial(self) -> None:
        """9.3 Simular condición de prioridad sin depender de sensores."""
        print("\n⚡ SIMULAR EVENTO ESPECIAL")
        inter = input("  Intersección objetivo (ej. INT_B2): ").strip().upper()
        print("  Forzando VERDE con alta prioridad (duración 90s)...")
        t0 = time.time()
        r  = self._analitica({"tipo": "FORZAR_VERDE", "interseccion": inter})
        lat = int((time.time() - t0) * 1000)
        print(f"  Resultado: {r.get('status')} | Latencia: {lat} ms")

    def restablecer_operacion(self) -> None:
        """9.4 Restablecer operación normal en todo el sistema."""
        print("\n↺ RESTABLECER OPERACIÓN NORMAL")
        conf = input("  ¿Confirmar restablecimiento? (s/n): ").strip().lower()
        if conf != "s":
            print("  Cancelado.")
            return
        r = self._analitica({"tipo": "RESTABLECER"})
        print(f"  Resultado: {r.get('status')} — {r.get('mensaje','')}")

    # ════════════════════════════════════════════════════════════════
    # MENÚ PRINCIPAL
    # ════════════════════════════════════════════════════════════════

    def menu(self) -> None:
        """Muestra menú principal y despacha la opción elegida por el operador."""
        opciones = {
            # Consultas (sección 8)
            "1": ("Estado actual de una intersección",        self.consulta_estado_actual),
            "2": ("Consulta histórica (rango de tiempo)",     self.consulta_historica),
            "3": ("Eventos recientes de una intersección",    self.consulta_eventos_recientes),
            "4": ("Estado actual de todos los semáforos",     self.consulta_estado_semaforos),
            # Indicaciones directas (sección 9)
            "5": ("Forzar cambio de semáforo (VERDE/ROJO)",   self.forzar_cambio_semaforo),
            "6": ("Priorizar vía — ola verde (ambulancia)",   self.priorizar_via),
            "7": ("Simular evento especial",                  self.simular_evento_especial),
            "8": ("Restablecer operación normal",             self.restablecer_operacion),
            "0": ("Salir", None),
        }

        while True:
            print(f"\n{SEP}")
            print("  🚦 SISTEMA DE MONITOREO Y CONSULTA — TRÁFICO URBANO")
            print(f"  {ts_now()}")
            print(f"{SEP}")
            print("  — CONSULTAS —")
            for k in ("1","2","3","4"):
                print(f"  [{k}] {opciones[k][0]}")
            print("  — INDICACIONES DIRECTAS —")
            for k in ("5","6","7","8"):
                print(f"  [{k}] {opciones[k][0]}")
            print(f"  [0] Salir")
            print(f"{SEP}")
            op = input("  Seleccione: ").strip()

            if op == "0":
                print("[MONITOREO] Saliendo.")
                break
            elif op in opciones and opciones[op][1]:
                try:
                    opciones[op][1]()
                except Exception as e:
                    print(f"  ERROR: {e}")
            else:
                print("  Opción no válida.")


def main():
    """Punto de entrada CLI para iniciar la interfaz de monitoreo."""
    parser = argparse.ArgumentParser(description="Servicio de Monitoreo y Consulta")
    parser.add_argument("--config", default="../config.json")
    args = parser.parse_args()
    with open(args.config) as f:
        cfg = json.load(f)
    ServicioMonitoreo(cfg).menu()


if __name__ == "__main__":
    main()
