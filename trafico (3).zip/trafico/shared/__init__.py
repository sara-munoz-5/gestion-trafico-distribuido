"""Paquete compartido con modelos y utilidades comunes del sistema."""
