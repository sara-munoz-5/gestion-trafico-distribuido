"""
modelos.py — Clases de dominio compartidas entre todos los servicios.
Proyecto: Gestión Inteligente de Tráfico Urbano — PUJ 2026-10
"""
import json
from datetime import datetime, timezone
from enum import Enum


class EstadoTrafico(str, Enum):
    """Estados globales usados por Analítica para decidir acciones de control."""

    NORMAL      = "NORMAL"
    CONGESTION  = "CONGESTION"
    PRIORIZACION = "PRIORIZACION"


class EventoTrafico:
    """Evento generado por cualquier tipo de sensor."""

    def __init__(self, sensor_id: str, tipo_sensor: str, interseccion: str,
                 timestamp: str, datos: dict):
        self.sensor_id    = sensor_id
        self.tipo_sensor  = tipo_sensor
        self.interseccion = interseccion
        self.timestamp    = timestamp
        self.datos        = datos

    def to_dict(self) -> dict:
        """Serializa el evento en un diccionario plano listo para transporte."""
        return {
            "sensor_id":    self.sensor_id,
            "tipo_sensor":  self.tipo_sensor,
            "interseccion": self.interseccion,
            "timestamp":    self.timestamp,
            "datos":        self.datos,
        }

    def to_json(self) -> str:
        """Convierte el evento a JSON para enviarlo por ZeroMQ."""
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "EventoTrafico":
        """Reconstruye un evento desde su representación JSON."""
        d = json.loads(s)
        return cls(d["sensor_id"], d["tipo_sensor"],
                   d["interseccion"], d["timestamp"], d["datos"])


class ComandoSemaforo:
    """Comando de cambio de estado de semáforo enviado por Analítica o el operador."""

    ACCIONES = {"VERDE", "ROJO", "EXTENDER_VERDE"}

    def __init__(self, interseccion: str, accion: str,
                 duracion_seg: int = 15, origen: str = "ANALITICA"):
        assert accion in self.ACCIONES, f"Acción inválida: {accion}"
        self.interseccion = interseccion
        self.accion       = accion
        self.duracion_seg = duracion_seg
        self.origen       = origen
        self.timestamp    = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict:
        """Serializa el comando en un diccionario homogéneo para transporte."""
        return {
            "interseccion": self.interseccion,
            "accion":       self.accion,
            "duracion_seg": self.duracion_seg,
            "origen":       self.origen,
            "timestamp":    self.timestamp,
        }

    def to_json(self) -> str:
        """Convierte el comando a JSON para enviarlo a Control de Semáforos."""
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, s: str) -> "ComandoSemaforo":
        """Crea una instancia de comando a partir de un mensaje JSON recibido."""
        d = json.loads(s)
        return cls(d["interseccion"], d["accion"],
                   d.get("duracion_seg", 15), d.get("origen", "?"))


def ts_now() -> str:
    """Timestamp actual en ISO 8601 UTC."""
    return datetime.now(timezone.utc).isoformat()
